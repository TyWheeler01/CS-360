package com.example.tywheelercs360assignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private List<WeightEntry> weightList;
    private DatabaseHelper dbHelper;
    private ActivityDataActivity.OnDeleteClickListener deleteClickListener;

    public WeightAdapter(List<WeightEntry> weightList, DatabaseHelper dbHelper, ActivityDataActivity.OnDeleteClickListener listener) {
        this.weightList = weightList;
        this.dbHelper = dbHelper;
        this.deleteClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);
        holder.dateText.setText(entry.date);
        holder.weightText.setText(entry.weight);
        holder.deleteButton.setOnClickListener(v -> deleteClickListener.onDeleteClick(entry.id));
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public void updateList(List<WeightEntry> newList) {
        weightList = newList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, weightText;
        Button deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            weightText = itemView.findViewById(R.id.weightText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
