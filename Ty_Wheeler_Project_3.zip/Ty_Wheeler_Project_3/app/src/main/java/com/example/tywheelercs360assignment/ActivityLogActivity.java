package com.example.tywheelercs360assignment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityLogActivity extends AppCompatActivity {

    private EditText weightInput, dateInput;
    private Button buttonSaveLog;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        weightInput = findViewById(R.id.weightInput);
        dateInput = findViewById(R.id.dateInput);
        buttonSaveLog = findViewById(R.id.buttonSaveLog);
        dbHelper = new DatabaseHelper(this);

        buttonSaveLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = weightInput.getText().toString().trim();
                String date = dateInput.getText().toString().trim();

                if (weight.isEmpty() || date.isEmpty()) {
                    Toast.makeText(ActivityLogActivity.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean inserted = dbHelper.insertWeightLog(date, weight);
                if (inserted) {
                    Toast.makeText(ActivityLogActivity.this, "Log saved!", Toast.LENGTH_SHORT).show();

                    // ✅ Navigate back to ActivityDataActivity
                    Intent intent = new Intent(ActivityLogActivity.this, ActivityDataActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(ActivityLogActivity.this, "Error saving log", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
