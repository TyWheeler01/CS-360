package com.example.tywheelercs360assignment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // DEBUG: Insert a test user for login testing
        dbHelper.insertUser("admin", "admin123");

        // Login button functionality
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                Toast.makeText(MainActivity.this, "Trying: " + username + " / " + password, Toast.LENGTH_SHORT).show();
                System.out.println("LOGIN TRY: " + username + " / " + password);
                dbHelper.debugPrintUsers();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean valid = dbHelper.checkUser(username, password);
                    if (valid) {
                        Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        // ✅ Navigate to ActivityDataActivity
                        Intent intent = new Intent(MainActivity.this, ActivityDataActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Register button functionality
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean userExists = dbHelper.checkUserExists(username);
                    if (userExists) {
                        Toast.makeText(MainActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                    } else {
                        long result = dbHelper.insertUser(username, password);
                        if (result != -1) {
                            Toast.makeText(MainActivity.this, "Account created!", Toast.LENGTH_SHORT).show();
                            dbHelper.debugPrintUsers(); // Debug
                        } else {
                            Toast.makeText(MainActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}
