package com.example.tywheelercs360assignment;

public class WeightEntry {
    public int id;
    public String date;
    public String weight;

    public WeightEntry(int id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }
}
