package com.example.tywheelercs360assignment;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ActivityDataActivity extends AppCompatActivity {

    private Button logWeightButton;
    private RecyclerView weightRecyclerView;
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;
    private ImageButton smsIconButton;
    private ImageButton goalWeightButton;
    private TextView goalWeightText;

    public interface OnDeleteClickListener {
        void onDeleteClick(int id);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        dbHelper = new DatabaseHelper(this);
        logWeightButton = findViewById(R.id.logWeightButton);
        weightRecyclerView = findViewById(R.id.weightRecyclerView);
        smsIconButton = findViewById(R.id.smsIconButton);
        goalWeightButton = findViewById(R.id.goalWeightButton);
        goalWeightText = findViewById(R.id.goalWeightText);

        logWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(ActivityDataActivity.this, ActivityLogActivity.class);
            startActivity(intent);
        });

        smsIconButton.setOnClickListener(v -> {
            Intent intent = new Intent(ActivityDataActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });

        goalWeightButton.setOnClickListener(v -> showGoalWeightDialog());

        updateGoalWeightText();

        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightAdapter(
                dbHelper.getAllWeightLogs(),
                dbHelper,
                id -> {
                    dbHelper.deleteWeightLog(id);
                    reloadData();
                }
        );
        weightRecyclerView.setAdapter(adapter);
    }

    private void showGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(this);
        input.setHint("Enter goal weight (lbs)");
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String goal = input.getText().toString().trim();
            if (!goal.isEmpty()) {
                SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
                prefs.edit().putString("goal_weight", goal).apply();
                updateGoalWeightText();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void updateGoalWeightText() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        String goal = prefs.getString("goal_weight", "--");
        goalWeightText.setText("Goal Weight: " + goal);
    }

    private void reloadData() {
        List<WeightEntry> updatedList = dbHelper.getAllWeightLogs();
        adapter.updateList(updatedList);

        // check for goal weight and send SMS
        if (!updatedList.isEmpty()) {
            String goal = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                    .getString("goal_weight", null);
            if (goal != null) {
                try {
                    float goalWeight = Float.parseFloat(goal);
                    float latestWeight = Float.parseFloat(updatedList.get(0).weight);
                    if (latestWeight <= goalWeight) {
                        sendGoalReachedSMS(goal);
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        }
    }

    private void sendGoalReachedSMS(String goalWeight) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage("5554", null, "Congratulations! You've reached your goal weight of " + goalWeight + "!", null, null);
            Toast.makeText(this, "Goal weight SMS sent", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadData();
        updateGoalWeightText();
    }
}
