package com.example.tywheelercs360assignment;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private TextView permissionStatus;
    private Button requestPermissionButton;
    private Button skipButton;
    private TableRow notificationDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        permissionStatus = findViewById(R.id.permissionStatus);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        skipButton = findViewById(R.id.skipButton);
        notificationDisplay = findViewById(R.id.notificationDisplay);
        ImageButton backButton = findViewById(R.id.backButton);

        requestPermissionButton.setOnClickListener(v -> requestSMSPermission());

        skipButton.setOnClickListener(v -> {
            permissionStatus.setText("Permission denied. SMS features disabled.");
            notificationDisplay.setVisibility(View.GONE);
        });

        backButton.setOnClickListener(v -> finish());
    }

    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            permissionStatus.setText("Permission already granted.");
            sendGoalNotification();
        }
    }

    private void sendGoalNotification() {
        try {
            String phoneNumber = "5551234567";
            String message = "🎉 Congrats! You've reached your goal weight in the tracking app!";
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Notification sent via SMS.", Toast.LENGTH_SHORT).show();
            permissionStatus.setText("SMS Sent: " + message);
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionStatus.setText("Permission granted!");
                sendGoalNotification();
            } else {
                permissionStatus.setText("Permission denied. SMS features disabled.");
                notificationDisplay.setVisibility(View.GONE);
            }
        }
    }
}
